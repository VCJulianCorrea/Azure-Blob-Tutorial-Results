﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureBlobStorage.Domain
{
    public class UploadContent
    {
        public string Content { get; set; }

        public string FileName { get; set; }
    }
}
